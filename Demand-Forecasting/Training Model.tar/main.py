import os
import numpy as np
import pandas as pd
import os
#
from datasetsforecast.hierarchical import HierarchicalData
from hierarchicalforecast.core import HierarchicalReconciliation
from hierarchicalforecast.methods import  BottomUp, TopDown, MiddleOut, MinTrace, ERM
from statsforecast.core import StatsForecast
from statsforecast.models import AutoARIMA, Naive
from hierarchicalforecast.evaluation import HierarchicalEvaluation
from sklearn.metrics import mean_squared_error as mse
from sklearn.metrics import root_mean_squared_error as rmse
from datetime import datetime
import pandas as pd
from ai_core_sdk.models import Metric, MetricTag, MetricCustomInfo, MetricLabel
#
from ai_core_sdk.tracking import Tracking
aic_connection = Tracking()
#
# Variables
DATA_PATH_CALENDAR = '/app/data/calendar.csv'
DATA_PATH_TRAIN = '/app/data/sales_train_evaluation.csv'
MODEL_PATH = '/app/model/model.pkl'
#
# Load Datasets
#
calendar_df = pd.read_csv(DATA_PATH_CALENDAR, parse_dates=['date'])
calendar_df = calendar_df.loc[:, ['date', 'wm_yr_wk', 'd']]
df = pd.read_csv(DATA_PATH_TRAIN)
df = df.loc[df.item_id=='FOODS_3_819']
df_T = df.melt(id_vars=['id', 'item_id', 'dept_id', 'cat_id', 'store_id', 'state_id'])
df_T.drop(columns=['id'], inplace=True)
#
#Data Preparation
#
sales_df = df_T.merge(calendar_df, left_on='variable', right_on='d', how='left')
sales_df.rename(columns={'value': 'sales_qty'}, inplace=True)
df = sales_df.loc[sales_df.date >= '2014-01-01', ['date', 'store_id', 'sales_qty']]
df['state_id'] = df['store_id'].str[:2]
## Ensure that 'date' column is in datetime format
df['date'] = pd.to_datetime(df['date'])
# Add five years using DateOffset
df['date'] = df['date'] + pd.DateOffset(years=8)
# create the long format matrix: individual stores
df_ind = df.groupby(['date', 'store_id'])[['sales_qty']].sum()
df_ind.reset_index(inplace=True)
df_ind = df_ind.T.reset_index(drop=True).T
df_ind.columns = ['ds', 'unique_id', 'sales']
# create the long format matrix: state level
df_sta = df.groupby(['date', 'state_id'])[['sales_qty']].sum()
df_sta.reset_index(inplace=True)
df_sta.columns = ['ds', 'unique_id', 'sales']
# create the long format matrix: total level
df_tot = df.groupby(['date'])[['sales_qty']].sum()
df_tot.reset_index(inplace=True)
df_tot['unique_id'] = 'Total'
df_tot.columns = ['ds', 'sales', 'unique_id' ]
# combine all three
dfx = pd.concat([df_ind, df_sta, df_tot], axis = 0)
print(df_ind.shape, df_sta.shape, df_tot.shape, dfx.shape)
# format
xset = set(dfx.unique_id)
dfx.columns = ['ds','unique_id', 'y']
dfx['ds'] = pd.to_datetime(dfx['ds'])
S = np.zeros((len(xset), len([f for f in xset if '_' in f])))
# rows / columns
list1 = ['Total', 'CA','CA_1','CA_2','CA_3','CA_4','TX','TX_1','TX_2','TX_3','WI','WI_1','WI_2','WI_3']
list2 = ['CA_1','CA_2','CA_3','CA_4','TX_1','TX_2','TX_3','WI_1','WI_2','WI_3']
S = pd.DataFrame(S); S.index = list1; S.columns = list2
# encode the hierarchical structure
S.loc['Total'] = 1
S.loc['CA'][['CA_1','CA_2','CA_3', 'CA_4']] = 1
S.loc['TX'][['TX_1','TX_2','TX_3']] = 1
S.loc['WI'][['WI_1','WI_2','WI_3']] = 1
for x in S.columns:
    S.loc[x][x]= 1
S = S.astype(int)
tags = {}
tags['Country'] = np.array(['Total'], dtype=object)
tags['Country/State'] = np.array(['CA', 'TX', 'WI'], dtype=object)
tags['Country/State/Store'] = np.array(['CA_1', 'CA_2', 'CA_3', 'CA_4',  
                                        'TX_1', 'TX_2', 'TX_3',
                                        'WI_1', 'WI_2', 'WI_3'], dtype=object)
#
# # Metric Logging: Basic
aic_connection.log_metrics(
    metrics = [
        Metric(
            name= "N_observations", value= float(dfx.shape[0]), timestamp=datetime.utcnow()),
    ]
)
#
# Partition into Train and test dataset
#
horizon = 7 
x_test = dfx.groupby('unique_id').tail(horizon)
x_train = dfx.drop(x_test.index)
x_test = x_test.set_index('unique_id')
x_train = x_train.set_index('unique_id')
# Ensure the target column 'y' is numeric
x_train['y'] = pd.to_numeric(x_train['y'], errors='coerce')
# Drop or handle NaN values if any were introduced
x_train = x_train.dropna(subset=['y'])
#
#Final Model
#
# Compute base auto-ARIMA predictions
fcst = StatsForecast(df = x_train, models=[AutoARIMA(season_length= 7)], freq='D', n_jobs=-1)
x_hat = fcst.forecast(h = horizon)
xmat = pd.merge(left = x_test, right = x_hat, on = ['ds', 'unique_id'])
#scoring over test data
rmse = rmse(xmat['y'], xmat['AutoARIMA'])
# Metric Logging: Attaching to metrics to generated model
aic_connection.log_metrics(
    metrics = [
        Metric(
            name= "Test data RMSE",
            value= float(rmse),
            timestamp=datetime.utcnow(),
            labels= [
                MetricLabel(name="metrics.ai.sap.com/Artifact.name", value="demand-forecasting")
            ]
        )
    ]
)
#
# Save model
import pickle
pickle.dump(fcst, open(MODEL_PATH, 'wb'))
#
#Add tags
aic_connection.set_tags(
    tags= [
        MetricTag(name="Validation Set", value= "7 last days"), # your custom name and value
        MetricTag(name="Metrics", value= "RMSE"),
    ]
)